function _identity(x) {
  return x;
}

module.exports = _identity, module.exports.__esModule = true, module.exports["default"] = module.exports;